
This is a placeholder ASP.NET Core MVC structure for the EagleApp.

To complete the project:
1. Open Visual Studio
2. Create a new ASP.NET Core Web App (Model-View-Controller)
3. Add the provided Eagle.cs model to the Models folder
4. Use scaffolding to generate the controller and views from the Eagle model
5. Add the link in _Layout.cshtml
6. Use Add-Migration and Update-Database in Package Manager Console

.NET version: Make sure you target .NET 6 or higher
