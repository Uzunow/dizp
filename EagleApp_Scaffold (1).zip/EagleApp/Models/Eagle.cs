
using System.ComponentModel.DataAnnotations;

namespace EagleApp.Models
{
    public class Eagle
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public double Wingspan { get; set; }
        public string Species { get; set; }
    }
}
